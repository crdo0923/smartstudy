<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: auth.php');
    exit();
}

// Minimal PHP variables retained just for structure (though not used in final UI elements)

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messaging - SmartStudy</title>
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/messaging.css"> 
    <link rel="stylesheet" href="css/loading.css">
</head>
<body class="no-sidebar-layout">
    
    <div class="page-loader">
        <div class="loader-container">
            <div class="loader-icon">💬</div>
            <div class="loader-text">Loading Chats...</div>
            <div class="loader-spinner">
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
            </div>
        </div>
    </div>

    <main class="main-content full-width-layout">
        <section id="messaging-section" class="content-section active">
            
            <div class="page-top-controls">
                
                <a href="dashboard.php" class="btn-back">
                    ← Back to Dashboard
                </a>
                
                <div class="section-header">
                    <h1>💬 Private Messaging</h1>
                    <p>Connect and collaborate with your study peers.</p>
                </div>
            </div>
            
            <div class="messaging-container">
                
                <div class="chat-list-panel">
                    <div class="search-bar">
                        <input type="text" placeholder="Search chats or contacts...">
                    </div>
                    <div class="chat-list">
                        <div class="chat-item active">
                            <div class="chat-avatar">R</div>
                            <div class="chat-info">
                                <h4 class="chat-name">Rica Mae B.</h4>
                                <p class="last-message">Hello! Pwede magtanong about sa project?</p>
                            </div>
                            <div class="chat-meta">
                                <span class="chat-time">10:30 AM</span>
                                <span class="chat-unread-count">1</span>
                            </div>
                        </div>
                        <div class="chat-item">
                            <div class="chat-avatar" style="background-color: #f59e0b;">J</div>
                            <div class="chat-info">
                                <h4 class="chat-name">John Rey A.</h4>
                                <p class="last-message">Sige, bukas na lang tayo mag-review.</p>
                            </div>
                            <div class="chat-meta">
                                <span class="chat-time">Yesterday</span>
                            </div>
                        </div>
                        <div class="chat-item">
                            <div class="chat-avatar" style="background-color: #be185d;">A</div>
                            <div class="chat-info">
                                <h4 class="chat-name">AI Study Group</h4>
                                <p class="last-message">Group: Next meeting is on Monday.</p>
                            </div>
                            <div class="chat-meta">
                                <span class="chat-time">Mon</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="chat-window-panel">
                    <div class="chat-header">
                        <div class="chat-header-info">
                            <div class="chat-avatar">R</div>
                            <div>
                                <h3>Rica Mae B.</h3>
                                <p class="chat-status">Active now</p>
                            </div>
                        </div>
                        <button class="btn-chat-options">...</button>
                    </div>

                    <div class="message-area" id="messageArea">
                        <div class="message-bubble incoming">
                            <p>Hi! Gusto ko sana magtanong tungkol doon sa Chapter 5 normalization, medyo nalilito ako sa 3NF.</p>
                            <span class="message-time">10:28 AM</span>
                        </div>
                        
                        <div class="message-bubble outgoing">
                            <p>Sure, no problem! Saan ka specifically nalilito? Sa decomposition ba or sa dependency preservation?</p>
                            <span class="message-time">10:30 AM</span>
                        </div>
                        
                        <div class="message-bubble incoming">
                            <p>Sa decomposition po. Bakit kailangan alisin yung transitive dependency?</p>
                            <span class="message-time">10:32 AM</span>
                        </div>

                    </div>

                    <div class="message-input-area">
                        <input type="text" placeholder="Type a message..." id="messageInput">
                        <button class="btn-send">
                            <span>Send</span> ➡️
                        </button>
                    </div>
                </div>
            </div>

        </section>
    </main>

    <script src="js/main.js"></script> 
    <script src="js/messaging.js"></script>
    </body>
</html>